These files contain the arbor traces of the neurons used in the paper. The traces are based on the
raw image stacks, except for two files which are based on a basic deformation of the volume, as
indicated by the file names. For details, please refer to github.com/uygarsumbul/rgc, which contains
neurons from a more heterogeneous dataset as well. The dataset used in this paper is a subset of
that dataset.

The traces use voxel coordinates where the voxel size is 0.4um x 0.4 um x 0.5 um. For trace files
using physical coordinates, please see github.com/uygarsumbul/rgc.

Genetic identities of neurons:
Image100-XXX : BDa
Image101-XXX : BDa

Image102-XXX : JAM-B
Image104-XXX : JAM-B

Image120-XXX : W3
Image121-XXX : W3
Image122-XXX : W3

