These files contain the arbor traces of the neurons used in the paper. The traces are based on the
raw image stacks, except for two files which are based on a basic deformation of the volume, as
indicated by the file names. For details, please refer to github.com/uygarsumbul/rgc, which contains
neurons from a more heterogeneous dataset as well. The dataset used in this paper is a subset of
that dataset.
