These files contain the automatically detected starburst amacrine arbor positions.
The variable minmesh (maxmesh) contains the depth coordinate of the On (Off) SAC
surface for each xy pair. The values are in pixel coordinates.


Genetic identities of neurons:
Image100-XXX : BDa
Image101-XXX : BDa

Image102-XXX : JAM-B 
Image104-XXX : JAM-B

Image120-XXX : W3
Image121-XXX : W3
Image122-XXX : W3

