The variable 'voxels' contains the physical coordinates of the voxels of the
3d trace-based reconstructions of the neurons. The values are in um, where the
depth values (voxels(:,:,3)) use the common depth coordinate, for which the
distance between the On (0um) and Off (12um) SAC surfaces is 12um, as described
in the paper.

The variable 'zDstribution' contains the registered depth profile in the interval
[-30um, 29.5um] with a step size of 0.5um. The sum of the variable gives the volume
of the reconstruction in um^3.
